// HB Prestige Jewels - Page Loader Controller
// Shows a branded loader overlay on every page navigation
// and auto-hides once the page has fully loaded.
(function () {
  const HIDE_DELAY = 300; // ms after load event before hiding

  function getLoader() {
    return document.getElementById('hb-page-loader');
  }

  function hideLoader() {
    const loader = getLoader();
    if (!loader) return;
    loader.classList.add('hb-loader--hidden');

    // Force scroll animations to fire for all in-viewport elements
    setTimeout(() => {
      window.dispatchEvent(new Event('scroll'));
      // Also manually remove offscreen class from any visible scroll-trigger elements
      document.querySelectorAll('.scroll-trigger.scroll-trigger--offscreen').forEach((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight + 100) {
          el.classList.remove('scroll-trigger--offscreen');
        }
      });
    }, 50);

    // Remove from DOM completely after transition ends so it never blocks
    setTimeout(() => {
      if (loader && loader.parentNode) {
        loader.parentNode.removeChild(loader);
      }
    }, 600);
  }

  function showLoader() {
    let loader = getLoader();
    if (loader) {
      loader.classList.remove('hb-loader--hidden');
      return;
    }

    // Re-create the loader element if it was removed
    loader = document.createElement('div');
    loader.id = 'hb-page-loader';
    loader.setAttribute('aria-hidden', 'true');
    loader.setAttribute('role', 'progressbar');

    // Logo image (from Shopify settings) or brand name text fallback
    const logoSrc = window.__hbLoaderLogo || '';
    const brandName = window.__hbLoaderBrand || 'HB';

    if (logoSrc) {
      const img = document.createElement('img');
      img.src = logoSrc;
      img.alt = brandName;
      img.className = 'hb-loader__logo';
      loader.appendChild(img);
    } else {
      const brand = document.createElement('div');
      brand.className = 'hb-loader__brand';
      brand.textContent = brandName;
      loader.appendChild(brand);
    }

    // Animated gold progress bar
    const track = document.createElement('div');
    track.className = 'hb-loader__bar-track';
    const fill = document.createElement('div');
    fill.className = 'hb-loader__bar-fill';
    track.appendChild(fill);
    loader.appendChild(track);

    document.body.insertBefore(loader, document.body.firstChild);
  }

  // --- Hide on initial page load ---
  function onLoad() {
    setTimeout(hideLoader, HIDE_DELAY);
  }

  if (document.readyState === 'complete') {
    onLoad();
  } else {
    window.addEventListener('load', onLoad);
  }

  // --- Show on every link click that navigates away ---
  document.addEventListener('click', function (e) {
    const link = e.target.closest('a');
    if (!link) return;

    const href = link.getAttribute('href');
    if (!href) return;

    // Ignore special links
    if (
      href.startsWith('#') ||
      href.startsWith('javascript') ||
      href.startsWith('mailto') ||
      href.startsWith('tel') ||
      link.hasAttribute('download') ||
      link.getAttribute('target') === '_blank' ||
      link.getAttribute('rel') === 'external'
    ) return;

    // Only show for same-origin navigation
    try {
      const url = new URL(href, window.location.href);
      if (url.origin !== window.location.origin) return;
      if (url.pathname === window.location.pathname && url.search === window.location.search) return;
    } catch (_) {
      return;
    }

    showLoader();
  });

  // --- Show on every external link click that navigates away ---
  window.addEventListener('pageshow', function (e) {
    if (e.persisted) {
      setTimeout(hideLoader, HIDE_DELAY);
    }
  });
})();
